package aula09;
public class Aula09 {
    public static void main(String[] args) {
        Publicacao l1=new Publicacao();
        l1.setTotPaginas(27);
        l1.setPagAtual(10);
        
       // l1.Folhear();
        
        Pessoa pes=new Pessoa();
        pes.setIdade(27);
        pes.fazerAniver();
    }
}
