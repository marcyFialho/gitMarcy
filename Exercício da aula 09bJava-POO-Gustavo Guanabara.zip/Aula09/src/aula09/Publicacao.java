package aula09;
public class Publicacao extends Livro {
    public void Abrir(){
      if(this.getAberto()==false){
          this.setAberto(true);
          System.out.println("Aberto com sucesso!");
      }  else {
          System.out.println("O livro já está aberto!");
      }
    }
    public void Fechar(){
      if(this.getAberto()==true){
          this.setAberto(false);
          System.out.println("Fechado com sucesso!");
      }  else {
          System.out.println("O livro já está fechado!");
      }    
    }
    public void Folhear(){
        System.out.println("Indo para o fim do livro!");
        for (int i=this.getPagAtual(); i<=this.getTotPaginas(); i++){
            this.setPagAtual(i+1);
            System.out.println(i);
        } 
        System.out.println("Voltando ao início do livro:");
        for (int i=this.getTotPaginas(); i>=0; i--){
        this.setPagAtual(i-1);
        System.out.println(i);
        }
    }
    public void avancarPag(){
      if(this.getAberto()==true){
        this.setPagAtual(this.getPagAtual()+1);
      }else{
          System.out.println("Por favor, abra o livri primeiro!");
      }
    }
    public void voltarPag(){
              if(this.getAberto()==true){
        this.setPagAtual(this.getPagAtual()-1);
      }else{
          System.out.println("Por favor, abra o livri primeiro!");
      }       
    }
}
