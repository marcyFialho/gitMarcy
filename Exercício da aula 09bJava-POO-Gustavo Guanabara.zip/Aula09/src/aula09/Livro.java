package aula09;
public class Livro {
    private String titulo;
    private String autor;
    private int totPaginas;
    private int pagAtual;
    private boolean aberto;
    private Pessoa leitor;

    public Livro() {
        this.aberto = false;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String t) {
        this.titulo = t;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String aut) {
        this.autor = aut;
    }

    public int getTotPaginas() {
        return totPaginas;
    }

    public void setTotPaginas(int tPags) {
        this.totPaginas = tPags;
    }

    public int getPagAtual() {
        return pagAtual;
    }

    public void setPagAtual(int pagA) {
        this.pagAtual = pagA;
    }

    public boolean getAberto() {
        return aberto;
    }

    public void setAberto(boolean a) {
        this.aberto = a;
    }

    public Pessoa getLeitor() {
        return leitor;
    }

    public void setLeitor(Pessoa l) {
        this.leitor = l;
    }
    
    public void Detalhes(){
        System.out.println("Título: "+titulo);
        System.out.println("Autor: "+ autor);
        System.out.println("Total de Páginas: "+totPaginas);
    }
}
